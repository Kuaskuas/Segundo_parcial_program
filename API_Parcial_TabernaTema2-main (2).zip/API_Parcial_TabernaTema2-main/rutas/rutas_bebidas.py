from flask import Blueprint, jsonify, request
from modelos.repositorios.repositorios import obtenerRepoBebidas
from modelos.entidades.bebida import Bebida
from modelos.entidades.refresco import Refresco 
from modelos.entidades.agua import Agua

bp_bebidas = Blueprint("bp_bebidas",__name__)

repo_bebidas = obtenerRepoBebidas()

def agregarBebida(self, bebida):
    self.__bebidas.append(bebida)
    self.__guardarBebidas()

@bp_bebidas.route("/bebidas", methods = ["GET"])
def listar_bebidas():
    return jsonify([ bebida.toDiccionario() for bebida in repo_bebidas.obtenerBebidas()])

@bp_bebidas.route("/bebidas/<string:nombre>", methods = ["GET"])
def obtener_bebida(nombre):
    bebida = repo_bebidas.obtenerBebidaPorNombre(nombre)
    if bebida == None:
        return jsonify({"error": "Bebida no encontrada"}), 404
    return jsonify(bebida.toDiccionario()),200 #correccion, si se devuelve el dato correctamente es codigo 200
@bp_bebidas.route("/bebidas/<string:nombre>", methods = ["DELETE"])
def eliminar_bebida(nombre):
    if repo_bebidas.eliminarBebida(nombre):
        return jsonify({"Mensaje":f"Bebida eliminada con éxito."}),200
    return jsonify({"error": "No se encontró la bebida a eliminar"}), 404

@bp_bebidas.route("/bebidas/<string:nombre>/precio", methods=["GET"])
def obtener_precio_bebida(nombre):
    bebida = repo_bebidas.obtenerBebidaPorNombre(nombre)
    if bebida is None:
        return jsonify({"error": "Bebida no encontrada"}), 404
    return jsonify({"nombre": bebida.obtenerNombre(), "precio": bebida.obtenerPrecio()}), 200 #correccion, si se devuelve el dato correctamente es codigo 200


@bp_bebidas.route("/bebidas", methods=["POST"])
def crear_bebida():
    data = request.json
    try:
        # Validaciones
        if "nombre" not in data or not data["nombre"] or data["nombre"].isspace():
            return jsonify({"error": "El nombre es requerido"}), 400
        if "costo" not in data or data["costo"] <= 0:
            return jsonify({"error": "El costo debe ser un número positivo"}), 400
        if "stock" not in data or data["stock"] <= 0:
            return jsonify({"error": "El stock debe ser un número positivo"}), 400
        if "mililitros" not in data or data["mililitros"] <= 0:
            return jsonify({"error": "Los mililitros deben ser un número positivo"}), 400
        
        # Crear la bebida
        if "origen" in data:
            bebida = Agua(
                nombre=data["nombre"],
                costo=data["costo"],
                stock=data["stock"],
                mililitros=data["mililitros"],
                origen=data["origen"]
            )
        else:
            bebida = Refresco(
                nombre=data["nombre"],
                costo=data["costo"],
                stock=data["stock"],
                mililitros=data["mililitros"],
                sabor=data["sabor"],
                gasificada=data["gasificada"]
            )
        repo_bebidas.agregarBebida(bebida)
        return jsonify(bebida.toDiccionario()), 200 
    except Exception as e:
        return jsonify({"error": str(e)}), 400 
    
    
@bp_bebidas.route("/bebidas/<string:nombre>", methods=["PUT"])
def actualizar_bebida(nombre):
    data = request.json
    bebida = repo_bebidas.obtenerBebidaPorNombre(nombre)
    if bebida is None:
        return jsonify({"error": "Bebida no encontrada"}), 404
    
    try:
        
        # Validaciones
        if "costo" in data and (data["costo"] <= 0):
            return jsonify({"error": "El costo debe ser un número positivo"}), 400
        if "stock" in data and (data["stock"] <= 0):
            return jsonify({"error": "El stock debe ser un número positivo"}), 400
        if "mililitros" in data and (data["mililitros"] <= 0):
            return jsonify({"error": "Los mililitros deben ser un número positivo"}), 400
    
        # Actualiza los atributos según los datos recibidos
        if "costo" in data:
            bebida.establecerCosto(data["costo"])
        if "stock" in data:
            bebida.establecerStock(data["stock"])
        if "mililitros" in data:
            bebida.establecerMililitros(data["mililitros"])
        
        if isinstance(bebida, Refresco):
            if "sabor" in data:
                bebida.establecerSabor(data["sabor"])
            if "gasificada" in data:
                bebida.establecerGasificada(data["gasificada"])
        
        elif isinstance(bebida, Agua):
            if "origen" in data:
                bebida.establecerOrigen(data["origen"])
        
        repo_bebidas.__guardarBebidas()  
        return jsonify(bebida.toDiccionario()), 200  # codigo 200 para (ok)
    except Exception as e:
        return jsonify({"error": str(e)}), 400  # codigo 400 para errores de validación (no ok)
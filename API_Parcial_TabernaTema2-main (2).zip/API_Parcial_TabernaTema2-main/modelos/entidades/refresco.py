from modelos.entidades.bebida import Bebida

class Refresco(Bebida):
    def __init__(self, nombre:str, costo:float, stock:int, mililitros:int, sabor: str, gasificada: bool):
        super().__init__(nombre, costo, stock, mililitros)
        if not isinstance(sabor, str) or sabor == "" or sabor.isspace():
            raise ValueError("El sabor debe ser un string")
        if not isinstance(gasificada, bool):
            raise ValueError("'gasificada' debe ser un valor booleano")
        self.__sabor = sabor
        self.__gasificada = gasificada

    def obtenerPrecio(self):
        return self._costo * 1.5
    
    def obtenerSabor(self):
        return self.__sabor
    
    def esGasificada(self):
        return self.__gasificada
    
    def establecerSabor(self, sabor:str):
        if not isinstance(sabor, str) or sabor == "" or sabor.isspace():
            raise ValueError("El sabor debe ser un string")
        self.__sabor = sabor
    
    def establecerGasificada (self, gasificada:bool):
        if not isinstance(gasificada, bool):
            raise ValueError("gasificada debe ser un valor booleano")
        self.__gasificada = gasificada

    @classmethod
    def fromDiccionario (cls, dicc:dict)-> "Refresco":
        if not isinstance(dicc, dict):
            raise ValueError("El parametro debe ser un diccionario")
        else:
            return cls(dicc["nombre"],dicc ["costo"], dicc ["stock"],dicc["mililitros"],dicc["sabor"],dicc["gasificada"])
    

    def toDiccionario(self):
        diccionario = super().toDiccionario()  
        diccionario["sabor"] = self.obtenerSabor()  
        diccionario["gasificada"] = self.esGasificada()  
        return diccionario
        
